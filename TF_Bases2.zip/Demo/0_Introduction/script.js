// Commentaire simple ligne en JS
/*
  Un commentaire
  sur
  plusieurs
  lignes
*/
//  CTRL + :

console.log('Bonjour')
console.warn('Bonjour');
console.error('Bonjour');